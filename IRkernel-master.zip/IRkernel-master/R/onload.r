.onLoad <- function(libname = NULL, pkgname = NULL) {
    init_options()
    init_backup_env()
}
